import taichi as ti
import numpy as np
import matplotlib.pyplot as plt
import ipdb
import sys

sys.path.append('../')
from rollers_suspension import rollers_suspension

# velocity vs efield scaling
efield_list_1 = np.linspace(1.2e6, 2e6, 10)
efield_list_2 = np.linspace(2e6, 4e6, 20)
efield_list = np.concatenate((efield_list_1, efield_list_2))
vel_list = np.zeros_like(efield_list)
output_dir = './data/'

for i in range(len(efield_list)):
    ti.init(arch=ti.gpu, default_fp=ti.f64, default_ip=ti.i32)
    E0 = efield_list[i]

    N = 1
    Lx = 1000
    Ly = 1000
    Lz = 1000
    steps = 1000
    deltaT = 0.0001

    output_freq = 10
    output_filename = 'rollers_efield_{:.2f}'.format(float(E0/1e5))

    # SI units
    radius = 2.5e-6 # particle radius
    viscosity = 0.003 # fluid viscosity

    epsilon0 = 8.8541878128e-12 # vacuum permittivity
    epsilon_p = 3.0 # particle permittivity
    epsilon_l = 2.0 # fluid permittivity

    sigma_p = 0 # particle conductivity
    sigma_l = 2e-8 # fluid conductivity

    epsilon_pl = (epsilon_p - epsilon_l) / (epsilon_p + 2*epsilon_l)
    sigma_pl = (sigma_p - sigma_l) / (sigma_p + 2*sigma_l)

    chi_inf = 4*np.pi*epsilon0*radius**3*epsilon_pl # high-frequency polarizability
    chi_0 = 4*np.pi*epsilon0*radius**3*sigma_pl # low-frequency polarizability
    tau_MW = epsilon0*(epsilon_p + 2*epsilon_l)/(sigma_p + 2*sigma_l) # Maxwell-Wagner relaxation time
    kT = 4.141947e-21 # thermal energy
    gap = 0.01 * radius # gap distance from the floor electrode

    # external field strength
    efield_type = 'Pulse'
    Ex = 0.0
    Ey = 0.0
    Ez = E0
    efield_T1 = 50000
    efield_T2 = 2500

    # fundamental units
    length_unit = 1e-6 # micrometer
    time_unit = 1 # second
    mass_unit = 1e-6 # milligram

    # derived quantities
    energy_unit = mass_unit*length_unit**2/time_unit**2
    viscosity_unit = mass_unit/(time_unit*length_unit)
    charge_unit = np.sqrt(4*np.pi*epsilon0*mass_unit*length_unit**3/time_unit**2)
    dipole_unit = charge_unit*length_unit
    force_unit = mass_unit*length_unit/time_unit**2
    polarizability_unit = 4*np.pi*epsilon0*length_unit**3
    efield_unit = force_unit / charge_unit

    # conversion
    radius /= length_unit
    viscosity /= viscosity_unit
    gap /= length_unit
    kT /= energy_unit
    Ex /= efield_unit
    Ey /= efield_unit
    Ez /= efield_unit
    chi_0 /= polarizability_unit
    chi_inf /= polarizability_unit
    tau_MW /= time_unit
    print(chi_0, chi_inf, tau_MW, Ez)

    # boundary
    wall_spacing = 2.1*radius
    wall_radius = min(Lx, Ly, Lz) / 2.0
    #N_wall = int(np.ceil(2 * np.pi * wall_radius / wall_spacing))
    N_wall = 0
    wall_shape = 'Circle'
    wall_type = 'No-slip'

    suspension = rollers_suspension(N=N, Lx=Lx, Ly=Ly, Lz=Lz,
            radius=radius, viscosity=viscosity,
            epsilon_p=epsilon_p, epsilon_l=epsilon_l, sigma_p=sigma_p,sigma_l=sigma_l,
            gap=gap, kT=kT,
            N_wall=N_wall, wall_spacing=wall_spacing, wall_shape=wall_shape, wall_type=wall_type,
            integrator='AB', deltaT=deltaT,
            integrator_dipole='RK2', periods_dipole=10,
            efield_type=efield_type, Ex=Ex, Ey=Ey, Ez=Ez,
            efield_T1=efield_T1, efield_T2=efield_T2,
            steps=steps)
    suspension.setup_outputs(output_dir=output_dir,
            output_filename=output_filename, output_freq=output_freq)
    suspension.init()
    suspension.solve()

    if suspension.gui != None:
        suspension.gui.close()

    vel = suspension.vel.to_numpy()
    vx = vel[0,0]
    vy = vel[0,1]
    vz = vel[0,2]
    vel_list[i] = np.sqrt(vx**2 + vy**2 + vz**2)

    # reset
    ti.reset()

# plot
fig = plt.figure(figsize=(4,3), dpi=300)
plt.plot(efield_list/1e6, vel_list, '-s')
plt.xlabel('Electric field strength ($V/\mu m$)')
plt.ylabel('steady velocity ($\mu m/s$)')
plt.grid()
plt.tight_layout()
plt.show()
fig.savefig(output_dir+'velocity-efield-scaling.png', dpi=300)
np.save(output_dir+'efield.npy',efield_list)
np.save(output_dir+'vel.npy',vel_list)
