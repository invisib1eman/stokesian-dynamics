# generate near-field lubrication resistance functions
# based on asymptotic expressions given by:
# Adam K. Townsend Generating, from scratch, the near-field asymptotic forms of scalar resistance functions for two unequal rigid spheres in low-Reynolds-number flow https://arxiv.org/abs/1802.08226
import numpy as np
import ipdb

output_file = 'res_scalars_AT.txt'
dist = np.geomspace(0.0001, 0.1, 1000) + 2.0
epsilon = dist - 2.0
X11A = 0.995419E0+(0.25E0)*(1.0/epsilon)+(0.225E0)*np.log((1.0/epsilon))+(0.267857E-1)*epsilon*np.log((1.0/epsilon));
X12A = (-0.350153E0)+(-0.25E0)*(1.0/epsilon)+(-0.225E0)*np.log((1.0/epsilon))+(-0.267857E-1)*epsilon*np.log((1.0/epsilon));
Y11A = 0.998317E0+(0.166667E0)*np.log((1.0/epsilon));
Y12A = (-0.273652E0)+(-0.166667E0)*np.log((1.0/epsilon));
Y11B = (-0.666667E0)*(0.23892E0+(-0.25E0)*np.log((1.0/epsilon))+(-0.125E0)*epsilon*np.log((1.0/epsilon)));
Y12B = (-0.666667E0)*((-0.162268E-2)+(0.25E0)*np.log((1.0/epsilon))+(0.125E0)*epsilon*np.log((1.0/epsilon)));
X11C = 0.133333E1*(0.10518E1+(-0.125E0)*epsilon*np.log((1.0/epsilon)));
X12C = 0.133333E1*((-0.150257E0)+(0.125E0)*epsilon*np.log((1.0/epsilon)));
Y11C = 0.133333E1*(0.702834E0+(0.2E0)*np.log((1.0/epsilon))+(0.188E0)*epsilon*np.log((1.0/epsilon)));
Y12C = 0.133333E1*((-0.27464E-1)+(0.5E-1)*np.log((1.0/epsilon))+(0.62E-1)*epsilon*np.log((1.0/epsilon)));

# output
with open(output_file, 'w') as f:
    for i in range(dist.size):
        f.write('{r} {XA} {YA} {YB} {XC} {YC}\n'.format(r=dist[i], XA=X11A[i], YA=Y11A[i], YB=Y11B[i], XC=X11C[i], YC=Y11C[i]))
        f.write('{r} {XA} {YA} {YB} {XC} {YC}\n'.format(r=dist[i], XA=X12A[i], YA=Y12A[i], YB=Y12B[i], XC=X12C[i], YC=Y12C[i]))

