import taichi as ti
import numpy as np
import scipy.sparse.linalg as spla
from functools import partial
import ipdb

@ti.data_oriented
class gmres_solver:
    '''
    linear system A*x = b solver based on the GMRES method
    '''
    def __init__(self, system):
        # parameters
        self.system = system
        self.N = 2 * system.dim * system.N_wall

        self.tol = system.gmres_tol
        self.maxiter = system.gmres_maxiter
        self.residual_on = system.gmres_residual_on
        self.save_prev_result = system.gmres_save_prev_result

        self.niter = 0
        self.info = 0
        self.resid = 0.0

        self.matvec = None
        self.x = None
        self.b = None
        self.Ax = None
        self.M = None

        # variables
        self.b_norm = None
        self.r_norm = None
        self.q_norm = None
        self.x0 = None # initial guess
        self.r = None # residual vector
        self.Q = None # orthonormal basis of Krylov subspace
        self.y = None # coefficients of Krylov base vectors
        self.H = None # Hessenberg matrix
        self.sn = None # Givens rotation coeffcients
        self.cs = None
        self.rhs = None # rhs of the linear least square problem
        self.e = None # residuals of each iteration

        self.layout()
        print('gmres solver initialized.')

    def layout(self):
        '''
        specify data layout related to GMRES solver
        '''
        self.x = ti.field(dtype=ti.f64)
        self.b = ti.field(dtype=ti.f64)
        self.Ax = ti.field(dtype=ti.f64)

        self.b_norm = ti.field(dtype=ti.f64, shape=1)
        self.r_norm = ti.field(dtype=ti.f64, shape=1)
        self.q_norm = ti.field(dtype=ti.f64, shape=1)
        self.x0 = ti.field(dtype=ti.f64)
        self.r = ti.field(dtype=ti.f64)
        self.Q = ti.field(dtype=ti.f64)
        self.H = ti.field(dtype=ti.f64)
        self.sn = ti.field(dtype=ti.f64)
        self.cs = ti.field(dtype=ti.f64)
        self.rhs = ti.field(dtype=ti.f64)
        self.e = ti.field(dtype=ti.f64)
        self.y = ti.field(dtype=ti.f64)

        ti.root.dense(ti.i, self.N).place(self.x)
        ti.root.dense(ti.i, self.N).place(self.b)
        ti.root.dense(ti.i, self.N).place(self.Ax)

        ti.root.dense(ti.i, self.N).place(self.x0)
        ti.root.dense(ti.i, self.N).place(self.r)
        ti.root.dense(ti.ij, (self.N, self.maxiter+1)).place(self.Q)
        ti.root.dense(ti.ij, (self.maxiter+1, self.maxiter)).place(self.H)
        ti.root.dense(ti.i, self.maxiter).place(self.sn)
        ti.root.dense(ti.i, self.maxiter).place(self.cs)
        ti.root.dense(ti.i, self.maxiter+1).place(self.rhs)
        ti.root.dense(ti.i, self.maxiter+1).place(self.e)
        ti.root.dense(ti.i, self.maxiter+1).place(self.y)

    def reset(self):
        '''
        reset gmres solver
        '''
        # reset counter and flag
        self.niter = 0
        self.info = 0
        self.resid = 0.0

        # clear linear operator and preconditioner
        self.matvec = None
        self.M = None

        # clear arrays
        self.clear_variables()

    @ti.kernel
    def clear_variables(self):
        '''
        clear related gpu variables
        '''
        # clear variables
        if self.save_prev_result == False:
            # defaul initial guess as zero vectors
            for i in ti.ndrange(self.N):
                self.x0[i] = 0.0

        for i in ti.ndrange(self.N):
            self.x[i] = 0.0
            self.b[i] = 0.0
            self.Ax[i] = 0.0
            self.r[i] = 0.0

        for i,j in self.Q:
            self.Q[i,j] = 0.0

        for i,j in self.H:
            self.H[i,j] = 0.0

        for i in ti.ndrange(self.maxiter):
            self.sn[i] = 0.0
            self.cs[i] = 0.0

        for i in ti.ndrange(self.maxiter+1):
            self.rhs[i] = 0.0
            self.e[i] = 0.0
            self.y[i] = 0.0

    def load_x0(self, x0):
        '''
        set the initial guess from numpy array
        '''
        self.x0.from_numpy(x0)

    def sanity_check(self):
        '''
        check whether necessary components are set
        '''
        if self.N <= 0:
            print('incorrect system size: N={N}'.format(N=self.N))
            return False
        if self.matvec == None:
            print('invalid linear operator.')
            return False
        return True

    def compute_residual(self):
        '''
        compute the residual of linear system: r = b - A*x
        '''
        # A * x
        self.matvec()

        # b - A*x
        self.init_residual()

    @ti.kernel
    def init_residual(self):
        '''
        r = b - A*x
        '''
        self.r_norm[0] = 0.0

        for i in ti.ndrange(self.N):
            self.r[i] = self.b[i] - self.Ax[i]
            self.r_norm[0] += self.r[i]**2

        self.r_norm[0] = ti.sqrt(self.r_norm[0])

        for i in ti.ndrange(self.N):
            self.r[i] /= self.r_norm[0]

        self.e[0] = self.r_norm[0]
        self.rhs[0] = self.r_norm[0]

    @ti.kernel
    def normalize_b(self):
        '''
        normalize b vector
        '''
        self.b_norm[0] = 0.0

        for i in ti.ndrange(self.N):
            self.b_norm[0] += self.b[i]**2

        self.b_norm[0] = ti.sqrt(self.b_norm[0])
        if self.b_norm[0] == 0:
            self.b_norm[0] = 1.0

        for i in ti.ndrange(self.N):
            self.b[i] /= self.b_norm[0]

    @ti.kernel
    def scale_x(self):
        '''
        scale the result back
        '''
        for i in ti.ndrange(self.N):
            self.x[i] *= self.b_norm[0]

    @ti.kernel
    def copy_x02x(self):
        '''
        copy x0 to x
        '''
        for i in ti.ndrange(self.N):
            self.x[i] = self.x0[i]

    @ti.kernel
    def copy_x2x0(self):
        '''
        copy x to x0
        '''
        for i in ti.ndrange(self.N):
            self.x0[i] = self.x[i]

    @ti.kernel
    def copy_qm2x(self, m: ti.i32):
        '''
        copy q_m to x
        '''
        for i in ti.ndrange(self.N):
            self.x[i] = self.Q[i,m]

    @ti.kernel
    def copy_Ax2qm(self, m: ti.i32):
        '''
        copy Ax to q_m
        '''
        for i in ti.ndrange(self.N):
            self.Q[i,m] = self.Ax[i]

    @ti.kernel
    def copy_r2qm(self, m: ti.i32):
        '''
        copy r to q_m
        '''
        for i in ti.ndrange(self.N):
            self.Q[i,m] = self.r[i]

    @ti.kernel
    def qmdotqn(self, m: ti.i32, n: ti.i32):
        '''
        dot product between Q[:,m] and Q[:,n]
        '''
        for i in ti.ndrange(self.N):
            self.H[n,m-1] += self.Q[i,m] * self.Q[i,n]

    @ti.kernel
    def qmsubsqn(self, m: ti.i32, n: ti.i32):
        '''
        substract H[n,m-1] * Q[:,n] from Q[:,m]
        '''
        for i in ti.ndrange(self.N):
            self.Q[i,m] -= self.H[n,m-1] * self.Q[i,n]

    @ti.kernel
    def normalize_q(self, m: ti.i32):
        '''
        normalize Q[:,m]
        '''
        self.q_norm[0] = 0.0

        for i in ti.ndrange(self.N):
            self.q_norm[0] += self.Q[i,m]**2

        self.q_norm[0] = ti.sqrt(self.q_norm[0])

        for i in ti.ndrange(self.N):
            self.Q[i,m] /= self.q_norm[0]

    @ti.kernel
    def update_Hmm(self, m: ti.i32):
        '''
        update H[m+1,m]
        '''
        self.H[m+1,m] = self.q_norm[0]

    def arnoldi(self, m):
        '''
        generate m+1-th orthonormal basis of the Krylov subspace
        '''
        # copy Q[:,m] to x
        self.copy_qm2x(m)

        # calculate A*q_m
        self.matvec()

        # copy Ax to Q[:,m+1]
        self.copy_Ax2qm(m+1)

        # Gram-Schmidt orthogonalization
        for i in range(m+1):
            # H[i,m] = Q[:,m+1] * Q[:,i]
            self.qmdotqn(m+1,i)
            # Q[:,m+1] -= H[i,m] * Q[:,i]
            self.qmsubsqn(m+1,i)

        # normalize Q[:,m+1]
        self.normalize_q(m+1)
        # update H[m+1,m]
        self.update_Hmm(m)

    @ti.func
    def apply_plane_rotation(self, m, n):
        '''
        apply m-th Givens rotation to H[m,n] and H[m+1,n]
        '''
        h1 = ti.Vector([0.0])
        h2 = ti.Vector([0.0])

        h1[0] =  self.cs[m] * self.H[m,n] + self.sn[m] * self.H[m+1,n]
        h2[0] = -self.sn[m] * self.H[m,n] + self.cs[m] * self.H[m+1,n]

        self.H[m,n] = h1[0]
        self.H[m+1,n] = h2[0]

    @ti.func
    def generate_givens_rotation(self, m):
        '''
        generate coefficients of Givens rotation
        '''
        norm = ti.sqrt(self.H[m,m]**2 + self.H[m+1,m]**2)

        self.cs[m] = self.H[m,m] / norm
        self.sn[m] = self.H[m+1,m] / norm

    @ti.kernel
    def givens_rotation(self, m: ti.i32):
        '''
        apply givens rotation to the H[:,m+1]
        '''
        # apply previous Givens rotations for H[i,m] and H[i+1,m]
        # forced serial
        for _ in range(1):
            for i in range(m):
                self.apply_plane_rotation(i,m)
            
        # generate the Givens rotation for H[m,m] and H[m+1,m]
        self.generate_givens_rotation(m)
        # apply the new Givens rotation
        self.apply_plane_rotation(m,m)
        # update rhs
        self.update_rhs(m)

    @ti.func
    def update_rhs(self, m):
        '''
        apply givens rotation to the rhs vector
        residual is the last element of rhs vector
        '''
        self.rhs[m+1] = -self.sn[m] * self.rhs[m]
        self.rhs[m] = self.cs[m] * self.rhs[m]

        self.e[m+1] = ti.abs(self.rhs[m+1])

    @ti.kernel
    def solve_Hy(self, m: ti.i32):
        '''
        H is upper triangular and solve H * y = rhs backwards
        '''
        # copy rhs to y
        for i in range(m):
            self.y[i] = self.rhs[i]

        # solve from bottom to top (forced serial)
        for _ in range(1):
            # Taichi does not support reverse order loop yet
            # work around by manually generating correct index
            #for i in reversed(range(m)):
            for i in range(m):
                #self.y[i] /= self.H[i,i]
                i_rev = m - 1 - i
                self.y[i_rev] /= self.H[i_rev,i_rev]
                #for j in reversed(range(i)):
                for j in range(i_rev):
                    #self.y[j] -= self.H[j,i] * self.y[i]
                    j_rev = i_rev - 1 - j
                    self.y[j_rev] -= self.H[j_rev,i_rev] * self.y[i_rev]

        # sum up the solution x = x0 + Q * y
        for i,j in ti.ndrange(self.N, m):
            self.x[i] += self.y[j] * self.Q[i,j]

    def solve(self):
        '''
        solve the linear system: A * x = b
        '''
        # sanity check
        if self.sanity_check() == False:
            self.info = -1
            return self.info

        # copy x0 to x 
        self.copy_x02x()

        # normalize b vector
        self.normalize_b()

        # calculate the initial residual
        self.compute_residual()

        # get current residual
        self.resid = self.e[0] # data transfer from device to host
        if self.resid < self.tol:
            self.info = 0
            return self.info

        # output residual info and check initial guess
        if ti.static(self.residual_on == True):
            print('GMRES solver: iteration = {niter} residual = {resid}'.format(niter=self.niter, resid=self.resid))

        # add the first base vector of Krylov subspace
        self.copy_r2qm(0)

        # start iterations
        for i in range(self.maxiter):

            self.niter = i + 1

            # construct i+1-th orthonormal base vector of the Krylov subspace
            self.arnoldi(i)

            # diagonalize the Hessenberg matrix
            self.givens_rotation(i)

            # get current residual
            self.resid = self.e[i+1] # data transfer from device to host

            # output info
            if ti.static(self.residual_on == True):
                print('GMRES solver: iteration = {niter} residual = {resid}'.format(niter=self.niter, resid=self.resid))

            # check convergence based on tolerance
            if self.resid < self.tol:
                # tolerance reached
                self.info = 0
                # copy x0 to x
                self.copy_x02x()
                # solve the result H * y = rhs
                self.solve_Hy(self.niter)
                # save solution as initial guess
                if ti.static(self.save_prev_result == True):
                    self.copy_x2x0()
                # scale back the solution x *= b_norm
                self.scale_x()
                return self.info

        # fail to converge within the max iteration steps
        self.info = 1
        print('Failed to converge. maxiter={maxiter} tol={tol}'.format(maxiter=self.maxiter, tol=self.tol))
        return self.info

def gmres_solver_cpu(A, b, x0=None, tol=1e-5, restart=None, maxiter=None, M=None, callback=None, PC_side='right'):
    '''
    wrapper for scipy gmres with left or right preconditioner

    right preconditioner:
        first, solve A*P^{-1} * y = b for y;
        then, solve P*x = y for x.

    left preconditioner:
        solve P^{-1}*A*x = P^{-1}*b
    '''
    # left preconditioner or no preconditioner
    if PC_side == 'left' or M is None:
        return spla.gmres(A, b, x0=x0, tol=tol, restart=restart, maxiter=maxiter, M=M, callback=callback)

    # right preconditioner
    A_LO = spla.aslinearoperator(A)
    M_LO = spla.aslinearoperator(M)

    # define A*P^{-1}
    def APinv(x,A,M):
        return A.matvec(M.matvec(x))
    APinv_partial = partial(APinv, A=A_LO, M=M_LO)
    APinv_partial_LO = spla.LinearOperator((b.size,b.size), matvec=APinv_partial, dtype='float64')

    # solve A*P^{-1} * y = b
    (y, info) = spla.gmres(APinv_partial_LO, b, x0=None, tol=tol, restart=restart, maxiter=maxiter, callback=callback)

    # solve P * x = y
    x = M_LO.matvec(y)

    return (x, info)

class gmres_counter(object):
    '''
    A simple counter for GMRES solver
    '''
    def __init__(self, residual_on=False):
        self.residual_on = residual_on
        self.niter = 0
    def __call__(self, rk=None):
        self.niter += 1
        if self.residual_on == True:
            print('gmres iteration = {niter} residual = {rk}'.format(niter=self.niter, rk=rk))
